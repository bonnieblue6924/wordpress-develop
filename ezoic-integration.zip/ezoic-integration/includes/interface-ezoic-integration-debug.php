<?php
namespace Ezoic_Namespace;

interface iEzoic_Integration_Debug {
    public function get_debug_information();
    public function we_should_debug();
}
