<?php
  wp_enqueue_script( 'emote_js', 'https://i.emote.com/js/emote.js', false);
  echo '<div id="emote_com"></div>';
